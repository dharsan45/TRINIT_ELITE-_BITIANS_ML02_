Henry Dinh
CS 6375.001
Assignment 2

Logistic Regression algorithm running instructions:
Parameters: train/spam train/ham test/spam test/ham [lambda_constant]
Example command line execution: python LogisticRegression.py train/spam train/ham test/spam test/ham 1.0
Output: Number of correct guesses and accuracy on the test set for unfilitered and filtered data sets.