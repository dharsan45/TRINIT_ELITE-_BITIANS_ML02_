# Logistic-Regression-Text-Classification
Classifying emails as spam or ham (not spam) using the Logistic Regression algorithm in Python 2.7.
